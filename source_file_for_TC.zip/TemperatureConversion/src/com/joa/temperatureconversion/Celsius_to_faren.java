package com.joa.temperatureconversion;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Celsius_to_faren extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.celsius_to_fahren);
		
		Button calc = (Button)findViewById(R.id.btn1);
		calc.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				EditText number = (EditText)findViewById(R.id.num);
			
				TextView display = (TextView)findViewById(R.id.res2);
				
				
				double num = Double.parseDouble(number.getText().toString());
				
				num = num*1.8+32; /*Fahrenheit*/
				display.setText(num+"");
				
			}

			
		});
}
	
}

