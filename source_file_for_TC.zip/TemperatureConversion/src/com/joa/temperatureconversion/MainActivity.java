package com.joa.temperatureconversion;


import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Button c_to_f = (Button)findViewById(R.id.c_to_f);
		Button calc = (Button)findViewById(R.id.btn2);
		
		
		c_to_f.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				Intent intent = new Intent(v.getContext(), Celsius_to_faren.class);
				startActivityForResult(intent,0);
			}
		});
		
		
		
		
		calc.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				EditText number = (EditText)findViewById(R.id.num);
			
				TextView display = (TextView)findViewById(R.id.res1);
				
				
				double num = Double.parseDouble(number.getText().toString());
				
				num = (num-32)*5/9; /*Celsius*/
				display.setText(num+"");
				
			}

			
		});
	}
	
	
	
	
	
	
		/*calc.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				EditText number = (EditText)findViewById(R.id.num);
			
				TextView display = (TextView)findViewById(R.id.res2);
				
				
				double num = Double.parseDouble(number.getText().toString());
				
				num = num*1.8+32; /*farenheight*/
				/*display.setText(num+"");
				
			}

			
		});*/
		
		
		/*calc1.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
				EditText number = (EditText)findViewById(R.id.num);
			
				TextView disp1 = (TextView)findViewById(R.id.res1);
				
				
				double num1 = Double.parseDouble(number.getText().toString());
				
				num1 = (num1-32)*5/9; /*celsius*/
				/*disp1.setText(num1+"");
				
			}

			
		});*/
		
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

}
